#define RAYGUI_IMPLEMENTATION
#include <raylib.h>
#include <raygui.h>
#include <string.h> // Required for checking string inputs (strcmp)

int main(void) {
    InitWindow(1200, 900, "Coogle");
    SetTargetFPS(60);

    // Text Box States
    char input[128] = { 0 };
    bool editMode = false;

    Texture2D myTexture = LoadTexture("raygle.png");
    Texture2D loading = LoadTexture("rayload.png");

float rotation = 0;
double start = GetTime();

while (GetTime() - start < 2 && !WindowShouldClose()) {
    rotation += 180 * GetFrameTime();

    BeginDrawing();
    ClearBackground(RAYWHITE);

    DrawTexturePro(
        loading,
        (Rectangle){0, 0, loading.width, loading.height},
        (Rectangle){600, 450, 150, 150},
        (Vector2){75, 75},
        rotation,
        WHITE
    );

    DrawText("Loading RAYGLE...", 500, 550, 24, BLACK);

    EndDrawing();
}

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground((Color){ 255, 255, 255, 255 });


        if (GuiTextBox((Rectangle){ 150, 430, 900, 40 }, input, 128, editMode)) {
            editMode = !editMode;
        }
        DrawRectangle(0, 850, 1200, 50, ColorAlpha(LIGHTGRAY, 0.4f));
        DrawRectangleLines(0, 850, 1200, 50, ColorAlpha(LIGHTGRAY, 0.2f)); // Subtle top border line
        DrawText("About    Advertising    Business    How Search works                                                                                                       Privacy    Terms", 30, 866, 16, GRAY);
        DrawText("Built with raygui and raylib!", 10, 800, 26, BLACK);
        GuiButton((Rectangle){ 430, 490, 160, 36 }, "RAYGLE Search");
        GuiButton((Rectangle){ 610, 490, 160, 36 }, "I'm Feeling EVIL");


        // 2. Conditional Output Actions based on what they typed
        // strcmp returns 0 if strings match exactly
        if (strstr(input, "hello")) {
            DrawText("Welcome to the system!", 250, 520, 50, GREEN);
        }
        else if (strstr(input, "linux")) {
             DrawText("Linux; is a kernel It manages the computer's hardware, memory, processes, etc", 120, 600, 24, BLACK);
        }
        else if (strstr(input, "ram")) {
            DrawText("RAM (Random Access Memory); is temporary memory your computer", 120, 600, 24, BLACK);
        }
        else if (strstr(input, "cpu")) {
            DrawText("Central Processing Unit; executes instructions for your computer", 120, 600, 24, BLACK);
        }
        else if (strstr(input, "gpu")) {
            DrawText("Graphics Processing Unit; processes graphics for your computer", 120, 600, 24, BLACK);
        }
        else if (strstr(input, "SSD")) {
            DrawText("Solid State Drive; Stores data using flash memory with no moving parts", 120, 600, 24, BLACK);
        }
        else if (strstr (input, "gnu")) {
            DrawText("GNU's Not Unix; A free software project that provides tools used with Linux.", 120, 600, 24, BLACK);
        }
        else if (strstr(input, "google")) {
            SetWindowTitle("...");

            while(!WindowShouldClose()) {
                BeginDrawing();
                ClearBackground(RED);
                DrawText("why would you say that... I thought we were friends...", 300, 900, 24, BLACK);
                DrawText("why would you say that... I thought we were friends...", 300, 800, 24, BLACK);
                DrawText("why would you say that... I thought we were friends...", 300, 700, 24, BLACK);
                DrawText("why would you say that... I thought we were friends...", 300, 600, 24, BLACK);
                DrawText("why would you say that... I thought we were friends...", 300, 500, 24, BLACK);
                DrawText("why would you say that... I thought we were friends...", 300, 400, 24, BLACK);
                DrawText("why would you say that... I thought we were friends...", 300, 300, 24, BLACK);
                DrawText("why would you say that... I thought we were friends...", 300, 200, 24, BLACK);
                DrawText("why would you say that... I thought we were friends...", 300, 100, 24, BLACK);
                DrawText("why would you say that... I thought we were friends...", 300, 0, 24, BLACK);
                EndDrawing();
            }

        }
        // 3. Draw your image anywhere on the canvas grid
        // Parameters: (loaded_texture, X_pos, Y_pos, color_tint)
        DrawTexture(myTexture, 100, 170, WHITE);

        EndDrawing();
    }

    // 4. Free GPU memory resources before closing the runtime
    UnloadTexture(myTexture);
    CloseWindow();

    return 0;
}
